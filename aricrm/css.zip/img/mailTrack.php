	<?php

	use App\Action;
	use App\Customer;

	//$asunto = "El email fue leido por ... ";
	//mail("soporterapido@myseocompany.co", $asunto);
	

	//<img src="https://mqe.com.co/img/mailTrack.php?id=XX" alt="" height="1" width="1" style="display:none;"/>

	public function action($user_id, $mail_id){

		$model = Customer::find($id);




	}

	?>

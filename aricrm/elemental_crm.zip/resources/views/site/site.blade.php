@extends('layout')

@section('content')
<img src="https://www.conoscenzealconfine.it/wp-content/uploads/2016/02/what-did-nelson-mandela-fight-for_4e148e13-f2dc-4fca-b2c4-92cecb6577aa.jpg" width="100%">
<div>
Nuestro mayor miedo, no es que no encajemos... Nuestro mayor miedo es que tenemos una fuerza inconmensurable, es nuestra luz y no nuestra oscuridad lo que más nos asusta, empequeñecerse no ayuda al mundo, no hay nada inteligente en encogerse para que otros no se sientan inseguros a tu alrededor, todos deberíamos brillar como hacen los niños, no es cosa de unos pocos, sino de todos, y al dejar brillar nuestra propia luz, insconcientemente damos permiso a otros para hacer lo mismo, al liberarnos de nuestro propio miedo, nuestra presencia libera automáticamente a otros
</div>

@endsection
<nav class="navbar navbar-expand-md navbar-white fixed-top bg-dark">

  <div id="nav-container" class="container">

      <div class="navbar-collapse collapse" id="navbarsExampleDefault" style="">
        <ul class="navbar-nav mr-auto">
       
        
      </div>   
  </div>
</nav> 
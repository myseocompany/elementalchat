<footer class="footer">
        <p>&copy; Elemental Para Tu Piel 2023</p>
        {{-- Dentro de tu archivo Blade orders/index.blade.php --}}
<p>Valor de la cookie unique_machine: {{ request()->cookie('unique_machine') }}</p>


</footer>
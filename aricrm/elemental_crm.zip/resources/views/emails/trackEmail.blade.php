	

	El usuario {!! $name !!} ha abierto el correo! </br><a href="https://mqe.com.co/customers/{!! $cid !!}/show">https://mqe.com.co/customers/{!! $cid !!}/show</a>

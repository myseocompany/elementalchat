<div style="height:100%;margin:0;padding:0;width:100%">
		
        <center>
            <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_-7084410255511821148m_600423363105295357bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
                <tbody><tr>
                    <td align="center" valign="top" id="m_-7084410255511821148m_600423363105295357bodyCell" style="height:100%;margin:0;padding:0;width:100%">
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
							<tbody><tr>
								<td align="center" valign="top" id="m_-7084410255511821148m_600423363105295357templateHeader" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_-7084410255511821148m_600423363105295357headerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:1px none;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/NeyROF-hadwhhem9QHarl8Rdz1rR_MNayILqcQG0kAKCFFk7ZTBoCSGAmOt-lRiFDN6ykAgHOHIlAXxpjOg1N41rA0b1ZpGxpfGLoxXUr8aXI7Vh8Mz57vfQATbm2uhqW7yfj7hU-tE_M7nxRJS8hIYnsL8JYWH7iQf10Hw=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/a9557a65-9339-4a5b-9261-2e8c0044cef1.png" width="537" style="max-width:537px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
							<tr>
								<td align="center" valign="top" id="m_-7084410255511821148m_600423363105295357templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:36px;padding-bottom:54px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_-7084410255511821148m_600423363105295357bodyContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/EH2Mn_CH1PAeu1tA4VuV3lN3iRUJdyhIKxKL1TUx9EDm5uypZhliKxvZ11KEIXx6c1Sitl-GpMnj2ISb6dEa0RVV4d1KdHgWl4sCpIFgGQYecEMjdy-mPt7Q34P5lCl8zUGr6c_dBmy5PzVWps85lwhQICsHyX7Fapz5NDs=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/3621bce9-31a2-4e89-8851-e6a0aa04f15a.gif" width="564" style="max-width:1920px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci4.googleusercontent.com/proxy/S1GF54iJoGrdJbBt9LHkCO5kPrSoxIP-jZqlzt4BsDDMirkkCbUL8vh9rw71V-8HDeDVYQUiVwP8JZtMWM5JQ3JGto6ift1DgTsXdBD5gUsf41G4q8nmE3R_Gr3MDaSRTloGNQ91Dwcmc5pduNyQAZrQEoKBVFvatDqNRxg=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/58a28ee3-882c-4fb2-91f6-d0310c99513e.jpg" width="552" style="max-width:552px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 707px; top: 729px;"><div id=":om" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V" data-tooltip="Descargar"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci4.googleusercontent.com/proxy/0dUIw7SZaxyVo5JvmycyZKYGhPuvyNIxxwbU3SUZlpp_xjYOAuURvkVfH-kAShh9f5FYKxD7Eu_Lr5I7OKD_VJ2etlgZPxEU9ZiqznWto_FldAKnnI-vKGoPJU4gorVo4tX_1VuWCmpn06hmMRAhR7R_maW1Ujr2mR4PLq4=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/91078cc5-87c8-4277-9df2-8a1baa6412dc.jpg" width="564" style="max-width:1285px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/SQNLZv9USjRUdYWl28TiZPiORbya0W1NChtfGZZL_aWVGZLz70x45rCXf7iNSvZM6YbWOB8TnKbvMtvWK9KcXgPNpknF7xmT2P9g3QE5qO1duBRo6hljTk-HYyKNmIThLGzQQ5FckqiqcffH-dj0ZqF2gcsWJ3U6NsEDL9o=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/d65280d4-0a45-45cc-9689-ef1eacad8af1.jpg" width="564" style="max-width:2048px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 713px; top: 1220.09px;"><div id=":on" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Descargar" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    <a href="https://goo.gl/maps/FcmNfRRxcN62" title="" rel="noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://goo.gl/maps/FcmNfRRxcN62&amp;source=gmail&amp;ust=1538098129491000&amp;usg=AFQjCNGb3d9b3cFQome4vXyHMAvhnOb6ng">
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/JR1dVr_AkNkskc1Th06nW7JIZCIm5BZw7B5c4XdNw8Fy3fXBuDHPt4BlorhjX_GjurAOV3GYqBH_LFagdSYuppvepnbmH_Spsu3TZ7CK_QUKoQDdyV_7RMBQiWJE9WG7AzuvEqJ-z5Q9LcRiRjTGMZdR4aDRWI-_VzRiNaY=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/c2d54652-a45e-4be7-b3fc-a6c232e159b2.jpg" width="564" style="max-width:1216px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd">
                                    </a>
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnBoxedTextBlock" style="min-width:100%;border-collapse:collapse">
    
	<tbody class="m_-7084410255511821148m_600423363105295357mcnBoxedTextBlockOuter">
        <tr>
            <td valign="top" class="m_-7084410255511821148m_600423363105295357mcnBoxedTextBlockInner">
                
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_-7084410255511821148m_600423363105295357mcnBoxedTextContentContainer">
                    <tbody><tr>
                        
                        <td style="padding-top:9px;padding-left:18px;padding-bottom:9px;padding-right:18px">
                        
                            <table border="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnTextContentContainer" width="100%" style="min-width:100%!important;background-color:#f9b200;border:10px none #f9b200;border-collapse:collapse">
                                <tbody><tr>
                                    <td valign="top" class="m_-7084410255511821148m_600423363105295357mcnTextContent" style="padding:18px;color:#f2f2f2;font-family:Helvetica;font-size:18px;font-weight:normal;text-align:center;word-break:break-word;line-height:150%">
                                        Presenta este cupón y obtén tu descuento para la compra de una máquina de empanadas
                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                </tbody></table>
				
                
				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7084410255511821148m_600423363105295357mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-7084410255511821148m_600423363105295357mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci3.googleusercontent.com/proxy/timfPAlaI4CHCTxdQivp-f9p8jDwNXmBpVwwthp37NLaV3CT_fuYZV-GyFb68xyRllq3THHDjvTO5Cip2qyAwlj-Kcn-5Tag8qlb0Ezp28tc3nqW6Z8f6_aEma8EAz85b1qRYitCuMp1Jbo9ynivZ341yYgtShEVGXbSGifbkL8hRVo=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/_compresseds/9871e13a-09d8-4de1-a1df-bffab98238b9.jpg" width="564" style="max-width:2350px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-7084410255511821148m_600423363105295357mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 713px; top: 2066.05px;"><div id=":oo" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Descargar" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                            <tr>
								<td align="center" valign="top" id="m_-7084410255511821148m_600423363105295357templateFooter" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_-7084410255511821148m_600423363105295357footerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnFollowBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnFollowBlockOuter">
        <tr>
            <td align="center" valign="top" style="padding:9px" class="m_-7084410255511821148m_600423363105295357mcnFollowBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnFollowContentContainer" style="min-width:100%;border-collapse:collapse">
    <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_-7084410255511821148m_600423363105295357mcnFollowContent">
                <tbody><tr>
                    <td align="center" valign="top" style="padding-top:9px;padding-right:9px;padding-left:9px">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top">
                                    
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-7084410255511821148m_600423363105295357mcnFollowIconContent">
                                                                                    <a href="http://www.facebook.com/maquiempanadasfans" rel="noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.facebook.com/maquiempanadasfans&amp;source=gmail&amp;ust=1538098129492000&amp;usg=AFQjCNE2N3YG3NkedjeCalpzBB_C2Tl-XA"><img src="https://ci4.googleusercontent.com/proxy/_lOpBfb7xgbdGKujI7K3onIEg3n4X5BW3kkMP0AKCG8fgHuqi2BwhMzam3P881p5jrt2W-6TVgI8EeceiUkYreQt_Ea1avPDlbMlf4NqgylDQA47jou-efljk0fUS7F3XVe6qqWQLJKp4Q=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-facebook-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-7084410255511821148m_600423363105295357mcnFollowIconContent">
                                                                                    <a href="http://www.instagram.com/maquiempanadas" rel="noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.instagram.com/maquiempanadas&amp;source=gmail&amp;ust=1538098129492000&amp;usg=AFQjCNFw7DFqOKVRj0RZiqeIh8KOP035pQ"><img src="https://ci4.googleusercontent.com/proxy/IpNRnA71KLuj629ljKqaEG5IsqXSijf8lMQQfqXVtOzww2g3dfe70hGHi_SEaYx3D3NsoTtCTRs9U8hNqo2Z9OqBE-Mc80zbJNDBiGi2cU2diNlcBltC6gFS1wzjzuwXZfCKieGmcyVzGqs=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-instagram-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:0;padding-bottom:9px" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-7084410255511821148m_600423363105295357mcnFollowIconContent">
                                                                                    <a href="http://maquiempanadas.com" rel="noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://maquiempanadas.com&amp;source=gmail&amp;ust=1538098129492000&amp;usg=AFQjCNFqEDDJXG5ReKBMGmrkcHnevOtyVQ"><img src="https://ci5.googleusercontent.com/proxy/DsMFEXv1Xu10XG4RMTrs170en_wG_VZcyCJ-DG7PQrCTZz9N9k9QJa0AsfNm8GoAAzAQQudUSS6BTnS4KpOAmK9nptmnm75Jwq1mMD4tOtZCyujKrxXeuM6SFccPNqesbBcH9CXI=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-link-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                    
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-7084410255511821148m_600423363105295357mcnTextBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-7084410255511821148m_600423363105295357mcnTextBlockOuter">
        <tr>
            <td valign="top" class="m_-7084410255511821148m_600423363105295357mcnTextBlockInner" style="padding-top:9px">
              	
			    
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_-7084410255511821148m_600423363105295357mcnTextContentContainer">
                    <tbody><tr>
                        
                        <td valign="top" class="m_-7084410255511821148m_600423363105295357mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#4caad8;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center">
                        
                            <span style="color:#ffffff"><em><span style="font-size:18px"><strong>CONTÁCTANOS</strong></span></em><br>
<br>
Carrera 34 No 64-24 Manizales-Colombia<br>
(+57) (6) 8875014 - (+57) 3206945548</span><br>
<br>
<span style="font-size:24px"><strong><span style="color:#ffffff">USA&nbsp;</span><a href="tel:1-305-280-7805" style="color:#ffffff;font-weight:normal;text-decoration:underline" rel="noreferrer" target="_blank"><span style="color:#ffffff">+1 305 280 7805</span></a></strong></span><br>
<br>
<span style="color:#ffffff"><em>Copyright © *Maquiempanadas</em></span>
                        </td>
                    </tr>
                </tbody></table>
				
                
				
            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                        </tbody></table>
                        
                    </td>
                </tr>
            </tbody></table>
        </center><div class="yj6qo"></div><div class="adL">
    </div></div>
    <img src="http://mqe.com.co/customers/{!! $customer_id !!}/actions/trackEmail/{!! $email_id !!}" width="0" height="0">
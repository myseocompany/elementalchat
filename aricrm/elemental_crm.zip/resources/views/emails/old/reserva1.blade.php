
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
	</head>
<body>
	<div class="container">
		<div class="">
			<div class="aHl">
			</div>
			<div id=":rz" tabindex="-1">
			</div><div id=":ro" class="ii gt">
				<div id=":rn" class="a3s aXjCH ">
					<div dir="ltr">
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
							Estimados clientes, es para nosotros muy gratificante contarles que se inicia venta de la Torre 4 del PROYECTO Conjunto Cerrado "RESERVA CAMPESTRE"
						</font>
						<span style="color:rgb(0,0,0);font-family:tahoma,sans-serif;font-size:large">
						ubicado en la Vía Panamericana frente al Barrio el Guamal.</span>
					</div>
						<div>
							<span style="color:rgb(0,0,0);font-family:tahoma,sans-serif;font-size:large">
							<br>
					</span>
					</div>
						<div>
							<span style="color:rgb(0,0,0);font-family:tahoma,sans-serif;font-size:large">
						El Proyecto inicialmente va a contar con 336 apartamentos, 226 parqueaderos para automóviles (comunales), 142 parqueaderos para motocicletas (comunales).</span>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
							<br>
					</font>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
						Se desarrollará por Torres. (Estas pueden variar en el transcurso de la obra, ya sea el número de unidades, apartamentos o parqueaderos)</font>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
							<br>
					</font>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
						Torre 5 - VENDIDA EN UN 90% -&nbsp; Edificio de 8 pisos, 8 apartamentos por piso, en total 64 unidades de 2 y de 3 alcobas. (Entrega en Septiembre de 2020)&nbsp;</font>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
							<br>
					</font>
					</div>
						<div>
							<font face="tahoma, sans-serif" color="#000000" size="4">
						Torre 4: Edificio 8 y 9 pisos, 8 apartamento por piso en total 68 unidades de 3 alcobas. (Entrega en Marzo de 2021)</font>
					</div>
						<div>
							<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font face="tahoma, sans-serif" size="4" color="#000000">
							<br>
					</font>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font face="tahoma, sans-serif" size="4" color="#000000">
						Reserva Campestre es un Proyecto que se puede adquirir con a sin subsidio</font>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font face="tahoma, sans-serif" size="4" color="#000000">
							<br>
					</font>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font face="tahoma, sans-serif" size="4" color="#000000">
						El s</font>
						<font face="tahoma, sans-serif" size="4" style="color:rgb(0,0,0)">
						ubsidio que se maneja por ahora es el de Vivienda CONFA, ya que estamos sujetos a la aprobación del MI CASA YA para años posteriores al 2019.</font>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,0)">
							<font face="tahoma, sans-serif" size="4">
							<br>
					</font>
					</div>
						<div>
							<div style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,0)">
						Imágenes de referencia:&nbsp; Las cuales pueden cambiar o sufrir modificaciones sin previo aviso.</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,255)">
							<br>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,255)">
						FACHADA TORRE 5</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,255)">
							<div>
							<br>
					</div>
						<div>
							<div>
							<img src="https://pranha.quirky.com.co/img/mailings/image.png" width="454" height="237" class="m_-1035190168547919375gmail-CToWUd m_-1035190168547919375gmail-a6T CToWUd" style="outline:0px">
						<br>
					</div>
						<br>
					</div>
						<div>
							<br>
					</div>
						<div>
						FACHADA DE TORRE 4, LOCAL Y SALÓN SOCIAL</div>
						<div>
							<br>
					</div>
						<div>
							<div>
							<img src="https://pranha.quirky.com.co/img/mailings/image-1.png" width="437" height="255" class="m_-1035190168547919375gmail-CToWUd m_-1035190168547919375gmail-a6T CToWUd" style="outline:0px">
						<br>
					</div>
						<div>
							<br>
					</div>
						<br>
					</div>
						<div>
							APARTAMENTO 3 ALCOBAS TORRE 4 $123.200.000 (Mzo/2021).&nbsp; Valor de separaciòn $2.000.000, cuota inicial 30%&nbsp; la cual se puede cancelar en 20 cuotas mensuales y se puede incluir subsibidio y el 70% con crèdito hipotecario.<br>
					</div>
						<div>
							<img src="https://pranha.quirky.com.co/img/mailings/image-2.png" width="454" height="278" class="m_-1035190168547919375gmail-CToWUd m_-1035190168547919375gmail-a6T CToWUd" style="outline:0px">
						<br>
					</div>
						<div>
							<div>
							<br>
					</div>
					</div>
						<div>
							<br>
					</div>
						<div>
							<div>
							<div>
							<br>
					</div>
					</div>
					</div>
						<div>
							<br>
					</div>
						<div>
							<br>
					</div>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font color="#000000">
						NOTA:</font>
					</div>
						<div style="font-family:tahoma,sans-serif;font-size:large">
							<span style="color:rgb(0,0,0);font-family:arial,sans-serif;font-size:12.8px">
						BALCÓN</span>
						<span style="font-family:arial,sans-serif;font-size:12.8px;color:rgb(0,0,0)">
						&nbsp;OPCIONAL DE 1.80 MTS2 ($2.100.000) EN TORRE 5</span>
						<br>
					</div>
						<div>
							<font color="#000000" face="arial, sans-serif">
							<span style="font-size:12.8px">
						BALCÓN</span>
					</font>
						<span style="font-family:arial,sans-serif;font-size:12.8px">
							<font color="#000000">
						&nbsp;OPCIONAL DE 1.80 MTS2 ($2.200.000) EN TORRE 4</font>
					</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<font color="#000000">
							<br>
					</font>
					</div>
						<div>
							<font color="#000000" face="arial, sans-serif">
							<span style="font-size:12.8px">
						CARACTERÍSTICAS</span>
					</font>
						<span style="font-family:arial,sans-serif;font-size:12.8px">
							<font color="#000000">
						&nbsp;DEL PROYECTO</font>
					</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							<br>
					</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							a.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Construcción industrializada.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							b.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Puerta principal del apartamento en madera aglomerada.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							c.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Puerta del Baño principal en madera aglomerada.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							d.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Enchapado el baño principal en la zona húmeda 2.00 m de altura.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							e.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Puntos hidráulicos y sanitarios en el baño auxiliar (caso de los aptos de 3 habitaciones).</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							f.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Instalación hidráulica&nbsp; en el baño principal con posibilidad de instalar agua caliente.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							g.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Mesón de la cocina en acero inoxidable con estufa (4 puestos) y lavaplatos.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							h.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						2 hiladas de enchape de salpicadero encima del mesón en la cocina</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							i.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Lavadero prefabricado</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							j.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						No se entrega la matrícula de gas natural ni el calentador.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							k.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Cubierta de techo en estructura metálica con tejas</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							l.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Ascensor por torre</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							n.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Tanque de Reserva de agua</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							o.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Planta eléctrica para zonas comunes</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							p.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Red contra incendios</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							q.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Portería</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							r.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Cancha múltiple</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							s.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Juegos infantiles</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							t.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Amplias Zonas Verdes.</span>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
							u.<span style="font-stretch:normal;font-size:7pt;line-height:normal;font-family:&quot;times new roman&quot;">
						&nbsp;&nbsp;&nbsp;&nbsp;</span>
					</span>
						<span style="color:rgb(0,0,0);font-size:12pt;line-height:17.12px">
						Salón Social</span>
					</div>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<br>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<br>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
						Cualquier duda, inquietud o comentario con gusto será atendida.</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<br>
					</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
						Cordial Saludo.</div>
						<div style="font-family:arial,sans-serif;font-size:12.8px">
							<p>
							<span style="font-family:&quot;ar cena&quot;">
						CENTRO DE NEGOCIOS PRANHA S.A.</span>
						<span style="font-size:9.5pt;font-family:&quot;ar cena&quot;">
						</span>
					</p>
						<p>
							<span style="font-family:&quot;ar cena&quot;">
						TEL: 8819662 – CEL:&nbsp;314-7917023 WP</span>
						<span style="font-size:9.5pt;font-family:&quot;ar cena&quot;">
						</span>
					</p>
						<p>
							<span style="font-family:&quot;ar cena&quot;">
							<a href="http://www.organizacionpranha.com/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.organizacionpranha.com/&amp;source=gmail&amp;ust=1563986818238000&amp;usg=AFQjCNFm3imkLO9HbveS-uujHrsW1xU4fA">
						www.pranhaurbano.com</a>
					</span>
						<span style="font-size:9.5pt;font-family:&quot;ar cena&quot;">
						</span>
					</p>
						<p>
							<span style="font-family:&quot;ar cena&quot;">
							clientes<a href="mailto:ventasmanizales@organizacionpranha.com" target="_blank">
						@pranhaurbano.com</a>
					</span>
						<span style="font-size:9.5pt;font-family:&quot;ar cena&quot;">
						</span>
					</p>
						<p style="font-size:12.8px">
						</p>
						<p>
							<br style="font-size:12.8px">
					</p>
					</div>
					</div>
					</div>
						<div class="yj6qo">
						</div>
						<div class="adL">
							
</div>
</div>
</div>
<div id=":s4" class="ii gt" style="display:none">
	<div id=":s3" class="a3s aXjCH undefined">
</div>
</div>
<div class="hi">
</div>
</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>

</body>
</html>
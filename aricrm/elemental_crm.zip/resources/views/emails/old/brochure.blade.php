
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
	</head>
<body>
	<div class="container">
		<div class="header">
			<img src="http://maquiempanadas.com/skin/frontend/tm_themes/theme740/images/logo_mqe.gif" class="img-fluid" alt="Responsive image">

		</div>
		
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja1.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja2.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja3.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja4.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja5.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja6.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja7.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja8.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja9.jpg" class="img-fluid" alt="Responsive image">
		</div>
		<br>
		
		<br>
		<div>
			<img src="http://maquiempanadas.com/imgs/hoja11.jpg" class="img-fluid" alt="Responsive image">
		</div>

		<img src="http://mqe.com.co/customers/{!! $customer_id !!}/actions/trackEmail/{!! $email_id !!}" width="0" height="0">
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>

</body>
</html>
<div class=""><div class="aHl"></div><div id=":ow" tabindex="-1"></div><div id=":p7" class="ii gt"><div id=":p8" class="a3s aXjCH msg6731885740277919255" role="gridcell" tabindex="-1"><u></u>

    
        
        
        
        
        
        
        
    
    <div style="height:100%;margin:0;padding:0;width:100%">
        
        <center>
            <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_6731885740277919255bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
                <tbody><tr>
                    <td align="center" valign="top" id="m_6731885740277919255bodyCell" style="height:100%;margin:0;padding:0;width:100%">
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top" id="m_6731885740277919255templateHeader" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_6731885740277919255headerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:1px none;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_6731885740277919255mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_6731885740277919255mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/NeyROF-hadwhhem9QHarl8Rdz1rR_MNayILqcQG0kAKCFFk7ZTBoCSGAmOt-lRiFDN6ykAgHOHIlAXxpjOg1N41rA0b1ZpGxpfGLoxXUr8aXI7Vh8Mz57vfQATbm2uhqW7yfj7hU-tE_M7nxRJS8hIYnsL8JYWH7iQf10Hw=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/a9557a65-9339-4a5b-9261-2e8c0044cef1.png" width="537" style="max-width:537px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_6731885740277919255mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" id="m_6731885740277919255templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:36px;padding-bottom:54px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_6731885740277919255bodyContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_6731885740277919255mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_6731885740277919255mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/3zeoHuoVBctjWGS7VTKr5c3v7Re6B7sR7InC9NDnT4yvM23YRapxyYrxwbOHfxfCUzbjOvWDjujLDe3_Q8Cx-X-8vtMkqVdSCD-gxsjpLHe8iCs704dLDy8Wb0VubvNvVivhaT0GI6juaYfrQXpLKnspUceV-V5t-h9Np4s=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/10f724c7-308a-402c-b361-4efd18fdd68b.gif" width="564" style="max-width:1920px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_6731885740277919255mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_6731885740277919255mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_6731885740277919255mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci3.googleusercontent.com/proxy/fYmEHO8v2BjJi0Qzc7yaS76tvtfgcEuhvmX3crmwyVeCmeeOyeLXr-HVClrSMRS-YXeixB7f0TYzqT95NMKwMjMMVKec9S-2z_CWhTw4qWNaDTnkDF1InFYqXO9bASrXdWrLuOxB5qxWr1HKMQCRAEHaq0xlnKu6A16bPZw=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/27684e3b-1b9e-496b-a151-b72068e09fe8.jpg" width="564" style="max-width:640px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_6731885740277919255mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 670px; top: 824px;"><div id=":qp" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V" data-tooltip="Descargar"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageCardBlock" style="border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageCardBlockOuter">
        <tr>
            <td class="m_6731885740277919255mcnImageCardBlockInner" valign="top" style="padding-top:9px;padding-right:18px;padding-bottom:9px;padding-left:18px">
                


<table border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightContentOuter" width="100%" style="border-collapse:collapse">
    <tbody><tr>
        <td align="center" valign="top" class="m_6731885740277919255mcnImageCardRightContentInner" style="padding:0px;background-color:#ffa200">
            <table align="left" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightImageContentContainer" width="200" style="border-collapse:collapse">
                <tbody><tr>
                    <td class="m_6731885740277919255mcnImageCardRightImageContent" align="left" valign="top" style="padding-top:18px;padding-right:0;padding-bottom:18px;padding-left:18px">
                    
                        

                        <img alt="" src="https://ci4.googleusercontent.com/proxy/4zqSyxJ7799o_vXomwtJLtuT0oAyhWPzsyE13g-IjMmpBureYxM0obibm-ZHSvy_0vXsGS1D_xrFjmrr8Vfzwz1kAY1j4fM049O-B6Ki-XVQeAeDqu2Qa7URwSl28s_FqXRwmwkbXJ65ZKmJ_gh21LodogE0WQGr8J_oDdk=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/9c37a527-2cab-4bf7-86ec-faef3b8f902a.jpg" width="182" style="max-width:246px;border:0;height:auto;outline:none;text-decoration:none;vertical-align:bottom" class="m_6731885740277919255mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 306px; top: 1062.55px;"><div id=":qn" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Descargar" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V"><div class="aSK J-J5-Ji aYr"></div></div></div>
                        

                    
                    </td>
                </tr>
            </tbody></table>
            <table class="m_6731885740277919255mcnImageCardRightTextContentContainer" align="right" border="0" cellpadding="0" cellspacing="0" width="346" style="border-collapse:collapse">
                <tbody><tr>
                    <td valign="top" class="m_6731885740277919255mcnTextContent" style="padding-right:18px;padding-top:18px;padding-bottom:18px;color:#f2f2f2;font-family:Helvetica;font-size:14px;font-weight:normal;text-align:center;word-break:break-word;line-height:150%">
                        <span style="font-size:13px"><span style="color:#ffffff">CONTENIDO DEL CURSO&nbsp;</span></span>

<ul>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Manejo de alimentos.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Mejoramiento técnico y operativo.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Frituras.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Salsas básicas.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Manejo de costos.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Conservación de alimentos.</span></span></li>
    <li style="text-align:left"><span style="font-size:13px"><span style="color:#ffffff">Aspectos legales para empezar tu negocio.&nbsp;</span></span></li>
</ul>

                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>


            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed!important">
    <tbody class="m_6731885740277919255mcnDividerBlockOuter">
        <tr>
            <td class="m_6731885740277919255mcnDividerBlockInner" style="min-width:100%;padding:18px">
                <table class="m_6731885740277919255mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px solid #ff9300;border-collapse:collapse">
                    <tbody><tr>
                        <td>
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageCardBlock" style="border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageCardBlockOuter">
        <tr>
            <td class="m_6731885740277919255mcnImageCardBlockInner" valign="top" style="padding-top:9px;padding-right:18px;padding-bottom:9px;padding-left:18px">
                


<table border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightContentOuter" width="100%" style="border-collapse:collapse">
    <tbody><tr>
        <td align="center" valign="top" class="m_6731885740277919255mcnImageCardRightContentInner" style="padding:0px;background-color:#1e96e0">
            <table align="left" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightImageContentContainer" width="200" style="border-collapse:collapse">
                <tbody><tr>
                    <td class="m_6731885740277919255mcnImageCardRightImageContent" align="left" valign="top" style="padding-top:18px;padding-right:0;padding-bottom:18px;padding-left:18px">
                    
                        

                        <img alt="" src="https://ci3.googleusercontent.com/proxy/mvCsdT7W1a_QHNWI_p4CxCpz11jBShcc_dm1SNsy_S6JxJoioaE6C7liCBuT8skZ7ivIIIk2d2zIvrxKcLZIM0bnrrK3omG24TT0HEbB-KEhl0iTMn7RCnu7-Ul_6Ka-8bUQRRjwKtuTkpu0ev1YFglc6XSVidzc4r5NH3I=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/e6cd356e-d09b-413f-877c-bc9d6d877ac8.jpg" width="182" style="max-width:270px;border:0;height:auto;outline:none;text-decoration:none;vertical-align:bottom" class="m_6731885740277919255mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 306px; top: 1358.11px;"><div id=":qm" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Descargar" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V"><div class="aSK J-J5-Ji aYr"></div></div></div>
                        

                    
                    </td>
                </tr>
            </tbody></table>
            <table class="m_6731885740277919255mcnImageCardRightTextContentContainer" align="right" border="0" cellpadding="0" cellspacing="0" width="346" style="border-collapse:collapse">
                <tbody><tr>
                    <td valign="top" class="m_6731885740277919255mcnTextContent" style="padding-right:18px;padding-top:18px;padding-bottom:18px;color:#f2f2f2;font-family:Helvetica;font-size:14px;font-weight:normal;text-align:center;word-break:break-word;line-height:150%">
                        <div style="text-align:center"><span style="color:#ffffff"><span style="font-size:13px">AL FINALIZAR EL CURSO LOS PARTICIPANTES PODRÁN</span></span></div>

<ul>
    <li style="text-align:left"><span style="color:#ffffff"><span style="font-size:13px">Conocer el manejo básico de los alimentos para preparar empanadas, salsas y frituras</span></span></li>
    <li style="text-align:left"><span style="color:#ffffff"><span style="font-size:13px">Aspectos generales para crear un emprendimiento de preparación y venta de empanadas.</span></span></li>
    <li style="text-align:left"><span style="color:#ffffff"><span style="font-size:13px">Diseñar un plan de negocios básico para crear una empresa de empanadas.</span></span></li>
</ul>

                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>


            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed!important">
    <tbody class="m_6731885740277919255mcnDividerBlockOuter">
        <tr>
            <td class="m_6731885740277919255mcnDividerBlockInner" style="min-width:100%;padding:18px">
                <table class="m_6731885740277919255mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px solid #ff9300;border-collapse:collapse">
                    <tbody><tr>
                        <td>
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnImageCardBlock" style="border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnImageCardBlockOuter">
        <tr>
            <td class="m_6731885740277919255mcnImageCardBlockInner" valign="top" style="padding-top:9px;padding-right:18px;padding-bottom:9px;padding-left:18px">
                


<table border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightContentOuter" width="100%" style="border-collapse:collapse">
    <tbody><tr>
        <td align="center" valign="top" class="m_6731885740277919255mcnImageCardRightContentInner" style="padding:0px;background-color:#1278be">
            <table align="left" border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnImageCardRightImageContentContainer" width="200" style="border-collapse:collapse">
                <tbody><tr>
                    <td class="m_6731885740277919255mcnImageCardRightImageContentE2E" align="left" valign="top" style="padding-top:0px;padding-right:0;padding-bottom:0px;padding-left:0px">
                    
                        

                        <img alt="" src="https://ci3.googleusercontent.com/proxy/6aSd6qmvIMi0wj_RKEDjb1hgiRFm__aOwBcaOFOUyw78sClbLjfmuBmzDBEEtd9DK-hOLGN0GA_BFwMcX8Y1ieloBwOljTWVocyfLNCXuoB7XFk9Wz94Boyx-tR3sVWfF5qsL4y_L2yc_vvg6kO-2xpkUNQZaJEngtvQJQs=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/7f1bfbad-7083-4a87-b143-9de99f35650c.gif" width="200" style="max-width:480px;border:0;height:auto;outline:none;text-decoration:none;vertical-align:bottom" class="m_6731885740277919255mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 306px; top: 1646px;"><div id=":qo" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" title="Descargar" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V"><div class="aSK J-J5-Ji aYr"></div></div></div>
                        

                    
                    </td>
                </tr>
            </tbody></table>
            <table class="m_6731885740277919255mcnImageCardRightTextContentContainer" align="right" border="0" cellpadding="0" cellspacing="0" width="346" style="border-collapse:collapse">
                <tbody><tr>
                    <td valign="top" class="m_6731885740277919255mcnTextContent" style="padding-right:18px;padding-top:18px;padding-bottom:18px;font-family:Helvetica;font-size:14px;font-weight:normal;text-align:center;word-break:break-word;color:#808080;line-height:150%">
                        <div style="text-align:left"><br>
<span style="font-size:18px"><span style="color:#ffffff">Duración: 16 horas<br>
Precio: $590.000<br>
Modalidad: Presencial&nbsp;<br>
Ciudad: Manizales</span></span></div>

                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>


            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnButtonBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnButtonBlockOuter">
        <tr>
            <td style="padding-top:0;padding-right:18px;padding-bottom:18px;padding-left:18px" valign="top" align="center" class="m_6731885740277919255mcnButtonBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" class="m_6731885740277919255mcnButtonContentContainer" style="border-collapse:separate!important;border-radius:3px;background-color:#ffa200">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" class="m_6731885740277919255mcnButtonContent" style="font-family:Arial;font-size:16px;padding:15px">
                                <a class="m_6731885740277919255mcnButton" title="SEPARA TU CUPO AQUÍ" href="https://api.whatsapp.com/send?phone=+57%20314%20835%208924&amp;text=Hola,%20me%20gustaría%20separa%20un%20cupo%20para%20la%20escuela%20de%20empanadas" style="font-weight:bold;letter-spacing:2px;line-height:100%;text-align:center;text-decoration:none;color:#ffffff;display:block" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://api.whatsapp.com/send?phone%3D%2B57%2520314%2520835%25208924%26text%3DHola,%2520me%2520gustar%C3%ADa%2520separa%2520un%2520cupo%2520para%2520la%2520escuela%2520de%2520empanadas&amp;source=gmail&amp;ust=1537631868749000&amp;usg=AFQjCNGsc7MgB_OT6UGmDNHbzK-DA94JpQ">SEPARA TU CUPO AQUÍ</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" id="m_6731885740277919255templateFooter" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_6731885740277919255footerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnFollowBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnFollowBlockOuter">
        <tr>
            <td align="center" valign="top" style="padding:9px" class="m_6731885740277919255mcnFollowBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnFollowContentContainer" style="min-width:100%;border-collapse:collapse">
    <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_6731885740277919255mcnFollowContent">
                <tbody><tr>
                    <td align="center" valign="top" style="padding-top:9px;padding-right:9px;padding-left:9px">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top">
                                    
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_6731885740277919255mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_6731885740277919255mcnFollowIconContent">
                                                                                    <a href="http://www.facebook.com/maquiempanadasfans" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.facebook.com/maquiempanadasfans&amp;source=gmail&amp;ust=1537631868749000&amp;usg=AFQjCNE_yFzStsKUGLvkMQQAvpSbg_tj6w"><img src="https://ci4.googleusercontent.com/proxy/_lOpBfb7xgbdGKujI7K3onIEg3n4X5BW3kkMP0AKCG8fgHuqi2BwhMzam3P881p5jrt2W-6TVgI8EeceiUkYreQt_Ea1avPDlbMlf4NqgylDQA47jou-efljk0fUS7F3XVe6qqWQLJKp4Q=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-facebook-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_6731885740277919255mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_6731885740277919255mcnFollowIconContent">
                                                                                    <a href="http://www.instagram.com/maquiempanadas" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.instagram.com/maquiempanadas&amp;source=gmail&amp;ust=1537631868749000&amp;usg=AFQjCNF_7F8FPU_vQPsLjWp2kSwhZdXEIg"><img src="https://ci4.googleusercontent.com/proxy/IpNRnA71KLuj629ljKqaEG5IsqXSijf8lMQQfqXVtOzww2g3dfe70hGHi_SEaYx3D3NsoTtCTRs9U8hNqo2Z9OqBE-Mc80zbJNDBiGi2cU2diNlcBltC6gFS1wzjzuwXZfCKieGmcyVzGqs=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-instagram-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:0;padding-bottom:9px" class="m_6731885740277919255mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_6731885740277919255mcnFollowIconContent">
                                                                                    <a href="http://maquiempanadas.com" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://maquiempanadas.com&amp;source=gmail&amp;ust=1537631868750000&amp;usg=AFQjCNHxYiAWytpnfFwimksqABNDDfPZfA"><img src="https://ci5.googleusercontent.com/proxy/DsMFEXv1Xu10XG4RMTrs170en_wG_VZcyCJ-DG7PQrCTZz9N9k9QJa0AsfNm8GoAAzAQQudUSS6BTnS4KpOAmK9nptmnm75Jwq1mMD4tOtZCyujKrxXeuM6SFccPNqesbBcH9CXI=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-link-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                    
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_6731885740277919255mcnTextBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_6731885740277919255mcnTextBlockOuter">
        <tr>
            <td valign="top" class="m_6731885740277919255mcnTextBlockInner" style="padding-top:9px">
                
                
                
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_6731885740277919255mcnTextContentContainer">
                    <tbody><tr>
                        
                        <td valign="top" class="m_6731885740277919255mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#4caad8;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center">
                        
                            <span style="color:#ffffff"><em><span style="font-size:18px"><strong>CONTÁCTANOS</strong></span></em><br>
<br>
Carrera 34 No 64-24 Manizales-Colombia<br>
<span style="font-size:18px">(+57) (6) 8875014 - (+57) 3206945548</span></span><br>
<span style="font-size:17px"><strong><span style="color:#ffffff">USA&nbsp;</span><a href="tel:1-305-280-7805" style="color:#ffffff;font-weight:normal;text-decoration:underline" target="_blank"><span style="color:#ffffff">+1 305 280 7805</span></a></strong></span><br>
<br>
<span style="color:#ffffff"><em>Copyright © *Maquiempanadas</em></span>
                        </td>
                    </tr>
                </tbody></table>
                
                
                
            </td>
        </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                        </tbody></table>
                        
                    </td>
                </tr>
            </tbody></table>
        </center><div class="yj6qo"></div><div class="adL">
    </div></div><div class="adL">

</div></div></div><div id=":os" class="ii gt" style="display:none"><div id=":or" class="a3s aXjCH undefined" role="gridcell" tabindex="-1"></div></div><div class="hi"></div></div>
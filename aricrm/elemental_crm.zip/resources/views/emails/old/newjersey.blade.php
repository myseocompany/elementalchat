<div class=""><div class="aHl"></div><div id=":nj" tabindex="-1"></div><div id=":n8" class="ii gt"><div id=":n7" class="a3s aXjCH m1655cb3c0254d91a"><u></u>

	
		
		
		
        
        
		
        
    
    <div style="height:100%;margin:0;padding:0;width:100%">
		
        <center>
            <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_1345015190352073731bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
                <tbody><tr>
                    <td align="center" valign="top" id="m_1345015190352073731bodyCell" style="height:100%;margin:0;padding:0;width:100%">
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
							<tbody><tr>
								<td align="center" valign="top" id="m_1345015190352073731templateHeader" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_1345015190352073731headerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:1px none;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/NeyROF-hadwhhem9QHarl8Rdz1rR_MNayILqcQG0kAKCFFk7ZTBoCSGAmOt-lRiFDN6ykAgHOHIlAXxpjOg1N41rA0b1ZpGxpfGLoxXUr8aXI7Vh8Mz57vfQATbm2uhqW7yfj7hU-tE_M7nxRJS8hIYnsL8JYWH7iQf10Hw=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/a9557a65-9339-4a5b-9261-2e8c0044cef1.png" width="537" style="max-width:537px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
							<tr>
								<td align="center" valign="top" id="m_1345015190352073731templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:36px;padding-bottom:54px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_1345015190352073731bodyContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/EH2Mn_CH1PAeu1tA4VuV3lN3iRUJdyhIKxKL1TUx9EDm5uypZhliKxvZ11KEIXx6c1Sitl-GpMnj2ISb6dEa0RVV4d1KdHgWl4sCpIFgGQYecEMjdy-mPt7Q34P5lCl8zUGr6c_dBmy5PzVWps85lwhQICsHyX7Fapz5NDs=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/3621bce9-31a2-4e89-8851-e6a0aa04f15a.gif" width="564" style="max-width:1920px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci4.googleusercontent.com/proxy/YrrAHDKFctHTtoZroVI4WzRNE4_KpwYU1Tmc6z1ivkxVQLkxTeVQy5wJWmHLnvG_h9zCTMOGYGF7Fvr3u6tPgWKrmrCb7mLIZTzMTXA1yX7DHF4-6Uo_Zth4wuSvA4SwCCWiZuq94M8t74n-ibZF7LdcJ0LUnb84G73QoIU=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/d68f1f47-aa1e-44dd-bf36-3937cd628894.jpg" width="564" style="max-width:1500px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 957px; top: 670.172px;"><div id=":oa" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V" data-tooltip="Descargar"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci4.googleusercontent.com/proxy/0dUIw7SZaxyVo5JvmycyZKYGhPuvyNIxxwbU3SUZlpp_xjYOAuURvkVfH-kAShh9f5FYKxD7Eu_Lr5I7OKD_VJ2etlgZPxEU9ZiqznWto_FldAKnnI-vKGoPJU4gorVo4tX_1VuWCmpn06hmMRAhR7R_maW1Ujr2mR4PLq4=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/91078cc5-87c8-4277-9df2-8a1baa6412dc.jpg" width="564" style="max-width:1285px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/SQNLZv9USjRUdYWl28TiZPiORbya0W1NChtfGZZL_aWVGZLz70x45rCXf7iNSvZM6YbWOB8TnKbvMtvWK9KcXgPNpknF7xmT2P9g3QE5qO1duBRo6hljTk-HYyKNmIThLGzQQ5FckqiqcffH-dj0ZqF2gcsWJ3U6NsEDL9o=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/d65280d4-0a45-45cc-9689-ef1eacad8af1.jpg" width="564" style="max-width:2048px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 957px; top: 1161.09px;"><div id=":o9" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V" data-tooltip="Descargar"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    <a href="https://goo.gl/maps/FcmNfRRxcN62" title="" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=https://goo.gl/maps/FcmNfRRxcN62&amp;source=gmail&amp;ust=1534945051447000&amp;usg=AFQjCNEMtDS3CMS-nFgoPMf3mFtiUI8I3A">
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/JR1dVr_AkNkskc1Th06nW7JIZCIm5BZw7B5c4XdNw8Fy3fXBuDHPt4BlorhjX_GjurAOV3GYqBH_LFagdSYuppvepnbmH_Spsu3TZ7CK_QUKoQDdyV_7RMBQiWJE9WG7AzuvEqJ-z5Q9LcRiRjTGMZdR4aDRWI-_VzRiNaY=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/c2d54652-a45e-4be7-b3fc-a6c232e159b2.jpg" width="564" style="max-width:1216px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd">
                                    </a>
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_1345015190352073731mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_1345015190352073731mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/DQjaPIetgdqljVb_DLRn7MO92vUztNI3HRfCe6zHjMzjfua2PZXBBMfZp54f6NluPCF29BDBhZbLmw1F2VjuYIgRiEO01aZHOkyMShUo27tS4hS065MT8mlS71D1FNoNBL1ZnaqID9OE0BpLzX4qeOXVFkRYqV1G7mTB21A=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/80e067e9-ba86-4b1c-abfe-ddca18beb3eb.jpg" width="552" style="max-width:552px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_1345015190352073731mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnButtonBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnButtonBlockOuter">
        <tr>
            <td style="padding-top:0;padding-right:18px;padding-bottom:18px;padding-left:18px" valign="top" align="center" class="m_1345015190352073731mcnButtonBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" class="m_1345015190352073731mcnButtonContentContainer" style="border-collapse:separate!important;border-radius:3px;background-color:#ffa200">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" class="m_1345015190352073731mcnButtonContent" style="font-family:Arial;font-size:16px;padding:15px">
                                <a class="m_1345015190352073731mcnButton" title="AGENDANDO TU CITA AQUÍ" href="http://newjersey.maquiempanadas.com/" style="font-weight:bold;letter-spacing:2px;line-height:100%;text-align:center;text-decoration:none;color:#ffffff;display:block" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://newjersey.maquiempanadas.com/&amp;source=gmail&amp;ust=1534945051447000&amp;usg=AFQjCNGkxu_pg1xZcJBvx30d4aByUlXGhg">AGENDANDO TU CITA AQUÍ</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                            <tr>
								<td align="center" valign="top" id="m_1345015190352073731templateFooter" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731templateContainer" style="border-collapse:collapse;max-width:600px!important">
										<tbody><tr>
                                			<td valign="top" class="m_1345015190352073731footerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnFollowBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnFollowBlockOuter">
        <tr>
            <td align="center" valign="top" style="padding:9px" class="m_1345015190352073731mcnFollowBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnFollowContentContainer" style="min-width:100%;border-collapse:collapse">
    <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_1345015190352073731mcnFollowContent">
                <tbody><tr>
                    <td align="center" valign="top" style="padding-top:9px;padding-right:9px;padding-left:9px">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top">
                                    
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_1345015190352073731mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_1345015190352073731mcnFollowIconContent">
                                                                                    <a href="http://www.facebook.com/maquiempanadasfans" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://www.facebook.com/maquiempanadasfans&amp;source=gmail&amp;ust=1534945051447000&amp;usg=AFQjCNHcyzxThDIXdnpRA_fknYR1rkunTg"><img src="https://ci4.googleusercontent.com/proxy/_lOpBfb7xgbdGKujI7K3onIEg3n4X5BW3kkMP0AKCG8fgHuqi2BwhMzam3P881p5jrt2W-6TVgI8EeceiUkYreQt_Ea1avPDlbMlf4NqgylDQA47jou-efljk0fUS7F3XVe6qqWQLJKp4Q=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-facebook-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_1345015190352073731mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_1345015190352073731mcnFollowIconContent">
                                                                                    <a href="http://www.instagram.com/maquiempanadas" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://www.instagram.com/maquiempanadas&amp;source=gmail&amp;ust=1534945051447000&amp;usg=AFQjCNHmiUQf81L-D6hl8bIeZs4UKSAb8Q"><img src="https://ci4.googleusercontent.com/proxy/IpNRnA71KLuj629ljKqaEG5IsqXSijf8lMQQfqXVtOzww2g3dfe70hGHi_SEaYx3D3NsoTtCTRs9U8hNqo2Z9OqBE-Mc80zbJNDBiGi2cU2diNlcBltC6gFS1wzjzuwXZfCKieGmcyVzGqs=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-instagram-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:0;padding-bottom:9px" class="m_1345015190352073731mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_1345015190352073731mcnFollowIconContent">
                                                                                    <a href="http://maquiempanadas.com" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://maquiempanadas.com&amp;source=gmail&amp;ust=1534945051447000&amp;usg=AFQjCNH4rZSC8XAM4WzODryO6GJyBveK7w"><img src="https://ci5.googleusercontent.com/proxy/DsMFEXv1Xu10XG4RMTrs170en_wG_VZcyCJ-DG7PQrCTZz9N9k9QJa0AsfNm8GoAAzAQQudUSS6BTnS4KpOAmK9nptmnm75Jwq1mMD4tOtZCyujKrxXeuM6SFccPNqesbBcH9CXI=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-link-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                    
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_1345015190352073731mcnTextBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_1345015190352073731mcnTextBlockOuter">
        <tr>
            <td valign="top" class="m_1345015190352073731mcnTextBlockInner" style="padding-top:9px">
              	
			    
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_1345015190352073731mcnTextContentContainer">
                    <tbody><tr>
                        
                        <td valign="top" class="m_1345015190352073731mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#4caad8;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center">
                        
                            <span style="color:#ffffff"><em><span style="font-size:18px"><strong>CONTÁCTANOS</strong></span></em><br>
<br>
Carrera 34 No 64-24 Manizales-Colombia<br>
(+57) (6) 8875014 - (+57) 3206945548</span><br>
<br>
<span style="font-size:24px"><strong><span style="color:#ffffff">USA&nbsp;</span><a href="tel:1-305-280-7805" style="color:#ffffff;font-weight:normal;text-decoration:underline" target="_blank"><span style="color:#ffffff">+1 305 280 7805</span></a></strong></span><br>
<br>
<span style="color:#ffffff"><em>Copyright © *Maquiempanadas</em></span>
                        </td>
                    </tr>
                </tbody></table>
				
                
				
            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                        </tbody></table>
                        
                    </td>
                </tr>
            </tbody></table>
        </center><div class="yj6qo"></div><div class="adL">
    </div></div><div class="adL">

</div></div></div><div id=":nn" class="ii gt" style="display:none"><div id=":no" class="a3s aXjCH undefined"></div></div><div class="hi"></div></div>
<img src="http://mqe.com.co/customers/{!! $customer_id !!}/actions/trackEmail/{!! $email_id !!}" width="0" height="0">
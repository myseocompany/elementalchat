<div style="height:100%;margin:0;padding:0;width:100%">
        
        <center>
            <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_-9127139891684338700bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
                <tbody><tr>
                    <td align="center" valign="top" id="m_-9127139891684338700bodyCell" style="height:100%;margin:0;padding:0;width:100%">
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top" id="m_-9127139891684338700templateHeader" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_-9127139891684338700headerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:1px none;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-9127139891684338700mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-9127139891684338700mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-9127139891684338700mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci6.googleusercontent.com/proxy/NeyROF-hadwhhem9QHarl8Rdz1rR_MNayILqcQG0kAKCFFk7ZTBoCSGAmOt-lRiFDN6ykAgHOHIlAXxpjOg1N41rA0b1ZpGxpfGLoxXUr8aXI7Vh8Mz57vfQATbm2uhqW7yfj7hU-tE_M7nxRJS8hIYnsL8JYWH7iQf10Hw=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/a9557a65-9339-4a5b-9261-2e8c0044cef1.png" width="537" style="max-width:537px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-9127139891684338700mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" id="m_-9127139891684338700templateBody" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:27px;padding-bottom:27px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_-9127139891684338700bodyContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-9127139891684338700mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-9127139891684338700mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-9127139891684338700mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci5.googleusercontent.com/proxy/3zeoHuoVBctjWGS7VTKr5c3v7Re6B7sR7InC9NDnT4yvM23YRapxyYrxwbOHfxfCUzbjOvWDjujLDe3_Q8Cx-X-8vtMkqVdSCD-gxsjpLHe8iCs704dLDy8Wb0VubvNvVivhaT0GI6juaYfrQXpLKnspUceV-V5t-h9Np4s=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/10f724c7-308a-402c-b361-4efd18fdd68b.gif" width="564" style="max-width:1920px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-9127139891684338700mcnImage CToWUd">
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnImageBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px" class="m_-9127139891684338700mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-9127139891684338700mcnImageContentContainer" style="min-width:100%;border-collapse:collapse">
                        <tbody><tr>
                            <td class="m_-9127139891684338700mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
                                
                                    
                                        <img align="center" alt="" src="https://ci4.googleusercontent.com/proxy/liyIlx5VozOIUyvYPu_aRnNnTtRQRSFjxZ_8cYIYU8IkHikiI1pCozsObzkswxIvTyvB54gEKMOGq8tD-x2X35bfqklR-xxod5P29OII5edNlMF9oBws-kBgGK5PFPbTKtW5WBTAMql0Kg8eHPLpLNW7Q35wO6skSv3LSCtm=s0-d-e1-ft#https://gallery.mailchimp.com/d5c52ab82e3e97c23f7e0f2de/images/707f3abd-31fb-4231-880a-7fe77524b9e2.jpeg" width="564" style="max-width:1000px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none" class="m_-9127139891684338700mcnImage CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 1023px; top: 818px;"><div id=":o7" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Descargar el archivo adjunto " data-tooltip-class="a1V" data-tooltip="Descargar"><div class="aSK J-J5-Ji aYr"></div></div></div>
                                    
                                
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnTextBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnTextBlockOuter">
        <tr>
            <td valign="top" class="m_-9127139891684338700mcnTextBlockInner" style="padding-top:9px">
                
                
                
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_-9127139891684338700mcnTextContentContainer">
                    <tbody><tr>
                        
                        <td valign="top" class="m_-9127139891684338700mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#808080;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                        
                            <div style="text-align:center"><span style="font-size:12px">Bono válido para compras de algunos de nuestro productos, no se cambiará por dinero en efectivo.</span></div>

                        </td>
                    </tr>
                </tbody></table>
                
                
                
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnButtonBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnButtonBlockOuter">
        <tr>
            <td style="padding-top:0;padding-right:18px;padding-bottom:18px;padding-left:18px" valign="top" align="center" class="m_-9127139891684338700mcnButtonBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" class="m_-9127139891684338700mcnButtonContentContainer" style="border-collapse:separate!important;border-radius:3px;background-color:#ffa200">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" class="m_-9127139891684338700mcnButtonContent" style="font-family:Arial;font-size:16px;padding:15px">
                                <a class="m_-9127139891684338700mcnButton" title="REDIME BONO AQUÍ" href="https://api.whatsapp.com/send?phone=573148358924&text=Quiero reclamar el bono de $500.000 de la polla mundialista" style="font-weight:bold;letter-spacing:2px;line-height:100%;text-align:center;text-decoration:none;color:#ffffff;display:block" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://newjersey.maquiempanadas.com/&amp;source=gmail&amp;ust=1535471174179000&amp;usg=AFQjCNGvph1k1V__zIZ-VlxcnP3-kcCAqg">REDIME BONO AQUÍ</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td align="center" valign="top" id="m_-9127139891684338700templateFooter" style="background:#1178be none no-repeat center/cover;background-color:#1178be;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                    
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                        <tbody><tr>
                                            <td valign="top" class="m_-9127139891684338700footerContainer" style="background:#transparent none no-repeat center/cover;background-color:#transparent;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnFollowBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnFollowBlockOuter">
        <tr>
            <td align="center" valign="top" style="padding:9px" class="m_-9127139891684338700mcnFollowBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnFollowContentContainer" style="min-width:100%;border-collapse:collapse">
    <tbody><tr>
        <td align="center" style="padding-left:9px;padding-right:9px">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_-9127139891684338700mcnFollowContent">
                <tbody><tr>
                    <td align="center" valign="top" style="padding-top:9px;padding-right:9px;padding-left:9px">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
                            <tbody><tr>
                                <td align="center" valign="top">
                                    
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_-9127139891684338700mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-9127139891684338700mcnFollowIconContent">
                                                                                    <a href="http://www.facebook.com/maquiempanadasfans" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://www.facebook.com/maquiempanadasfans&amp;source=gmail&amp;ust=1535471174180000&amp;usg=AFQjCNFEJAvT7AK4ipZgNNrRfKmaMjknUg"><img src="https://ci4.googleusercontent.com/proxy/_lOpBfb7xgbdGKujI7K3onIEg3n4X5BW3kkMP0AKCG8fgHuqi2BwhMzam3P881p5jrt2W-6TVgI8EeceiUkYreQt_Ea1avPDlbMlf4NqgylDQA47jou-efljk0fUS7F3XVe6qqWQLJKp4Q=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-facebook-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:10px;padding-bottom:9px" class="m_-9127139891684338700mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-9127139891684338700mcnFollowIconContent">
                                                                                    <a href="http://www.instagram.com/maquiempanadas" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://www.instagram.com/maquiempanadas&amp;source=gmail&amp;ust=1535471174180000&amp;usg=AFQjCNGg8mUTJhr5qoxssmaPC7Hc6Y4qkQ"><img src="https://ci4.googleusercontent.com/proxy/IpNRnA71KLuj629ljKqaEG5IsqXSijf8lMQQfqXVtOzww2g3dfe70hGHi_SEaYx3D3NsoTtCTRs9U8hNqo2Z9OqBE-Mc80zbJNDBiGi2cU2diNlcBltC6gFS1wzjzuwXZfCKieGmcyVzGqs=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-instagram-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                        
                                        
                                        
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                <tbody><tr>
                                                    <td valign="top" style="padding-right:0;padding-bottom:9px" class="m_-9127139891684338700mcnFollowContentItemContainer">
                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnFollowContentItem" style="border-collapse:collapse">
                                                            <tbody><tr>
                                                                <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                        <tbody><tr>
                                                                            
                                                                                <td align="center" valign="middle" width="24" class="m_-9127139891684338700mcnFollowIconContent">
                                                                                    <a href="http://maquiempanadas.com" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=es&amp;q=http://maquiempanadas.com&amp;source=gmail&amp;ust=1535471174180000&amp;usg=AFQjCNFU-D5FapErcNIcw14lMhFvAwW9uA"><img src="https://ci5.googleusercontent.com/proxy/DsMFEXv1Xu10XG4RMTrs170en_wG_VZcyCJ-DG7PQrCTZz9N9k9QJa0AsfNm8GoAAzAQQudUSS6BTnS4KpOAmK9nptmnm75Jwq1mMD4tOtZCyujKrxXeuM6SFccPNqesbBcH9CXI=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/outline-light-link-48.png" style="display:block;border:0;height:auto;outline:none;text-decoration:none" height="24" width="24" class="CToWUd"></a>
                                                                                </td>
                                                                            
                                                                            
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        
                                        
                                    
                                    
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>
</tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-9127139891684338700mcnTextBlock" style="min-width:100%;border-collapse:collapse">
    <tbody class="m_-9127139891684338700mcnTextBlockOuter">
        <tr>
            <td valign="top" class="m_-9127139891684338700mcnTextBlockInner" style="padding-top:9px">
                
                
                
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_-9127139891684338700mcnTextContentContainer">
                    <tbody><tr>
                        
                        <td valign="top" class="m_-9127139891684338700mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#4caad8;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center">
                        
                            <span style="color:#ffffff"><em><span style="font-size:18px"><strong>CONTÁCTANOS</strong></span></em><br>
<br>
Carrera 34 No 64-24 Manizales-Colombia<br>
<span style="font-size:22px">(+57) (6) 8875014 - (+57) 3206945548</span></span><br>
<span style="font-size:19px"><strong><span style="color:#ffffff">USA&nbsp;</span><a href="tel:1-305-280-7805" style="color:#ffffff;font-weight:normal;text-decoration:underline" target="_blank"><span style="color:#ffffff">+1 305 280 7805</span></a></strong></span><br>
<br>
<span style="color:#ffffff"><em>Copyright © *Maquiempanadas</em></span>
                        </td>
                    </tr>
                </tbody></table>
                
                
                
            </td>
        </tr>
    </tbody>
</table></td>
                                        </tr>
                                    </tbody></table>
                                    
                                </td>
                            </tr>
                        </tbody></table>
                        
                    </td>
                </tr>
            </tbody></table>
        </center><div class="yj6qo"></div><div class="adL">
    </div></div>
<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class CampaignMessage extends Model{
	protected $table = 'campaign_messages';
}
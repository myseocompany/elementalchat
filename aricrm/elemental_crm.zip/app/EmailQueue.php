<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class EmailQueue extends Model{


}
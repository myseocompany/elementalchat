<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Role;
use DB;
use App\Product;
use App\ProductType;
use App\ProductStatus;
use App\Category;


class OrderProductController extends Controller{



	public function edit($id){
		
	}
}
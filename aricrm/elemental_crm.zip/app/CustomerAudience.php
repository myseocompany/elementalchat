<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerAudience extends Model{


	protected $table = "audience_customer";
}
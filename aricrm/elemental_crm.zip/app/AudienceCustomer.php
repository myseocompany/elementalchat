<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AudienceCustomer extends Model
{

	protected $table = 'audience_customer';
}
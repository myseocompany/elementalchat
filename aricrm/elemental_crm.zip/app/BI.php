<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BI extends Model
{

	protected $table = "import_erp_2024_06_07";
}
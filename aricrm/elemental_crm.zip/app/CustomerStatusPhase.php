<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Action;

// use Laravel\Scout\Searchable;

class CustomerStatusPhase extends Model
{
    // use Searchable;
    //
    // function account(){
    // 	return $this->belongsTo('App\Account');
    // }

    /*
    function customer_files(){
        return $this->hasMany('App\CustomerFile');
    }
    public function status(){
    	return $this->belongsTo('App\CustomerStatus');
    }
	*/

}